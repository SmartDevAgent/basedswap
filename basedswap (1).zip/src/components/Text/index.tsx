export * from "./PreTitle";
export { default as SkeletonText } from "./SkeletonText";
export { default as Text } from "./Text";
export { default as TooltipText } from "./TooltipText";
export type { TextProps } from "./types";
