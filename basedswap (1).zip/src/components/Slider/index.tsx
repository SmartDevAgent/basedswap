export { default as Slider } from "./Slider";
export type { default as SliderProps } from "./types";
