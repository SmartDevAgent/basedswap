export enum SettingsMode {
  GLOBAL = 'GLOBAL',
  SWAP_LIQUIDITY = 'SWAP_LIQUIDITY',
}
