export { default as Select } from "./Select";
export type { OptionProps } from "./Select";
