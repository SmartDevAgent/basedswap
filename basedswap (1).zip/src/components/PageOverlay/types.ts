export type PageOverlayProps = {
  show: boolean;
  zIndex?: number;
};
