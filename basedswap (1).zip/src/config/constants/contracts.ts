import { ChainId } from 'config/chains'

export default {
  masterChef: {
    [ChainId.BASE]: '0x6c908d80261eb0BbB7e9102d5B38e1CEA0D25265',
  },
  multiCall: {
    [ChainId.BASE]: '0xcA11bde05977b3631167028862bE2a173976CA11',
  },
  multisender: {
    [ChainId.BASE]: '0xfba3E8396DDc92FD199ac7230a34c08Cb98149f2'
  },
  locker: {
    [ChainId.BASE]: '0xe0c103df6e032AA5bBc303a5ABE30801F434927e',
  },
  launchpadFactory: {
    [ChainId.BASE]: '0x1e7F25Af19DD9c3229d43041867c2924af6dd304',
  },
  contribution: {
    [ChainId.BASE]: '0x1e7F25Af19DD9c3229d43041867c2924af6dd304',
  },
  smartRouter: {
    [ChainId.BASE]: '0x1e7F25Af19DD9c3229d43041867c2924af6dd304',
  },
  treasury: {
    [ChainId.BASE]: '0x1e7F25Af19DD9c3229d43041867c2924af6dd304',
  },
  presale: {
    [ChainId.BASE]: '0x3f62bF60F03aaef7Be417A67e1463cf4e5db1d07',
  },
} as const satisfies Record<string, Record<number, `0x${string}`>>
