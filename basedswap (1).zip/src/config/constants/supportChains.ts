import { ChainId } from 'config/chains'

export const SUPPORTED_CHAINS = [ChainId.BASE]
