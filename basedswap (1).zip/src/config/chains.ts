import memoize from 'lodash/memoize'
import { Chain, base } from 'wagmi/chains'

export const baseMainnet = {
  blockExplorers: base.blockExplorers,
  contracts: base.contracts,
  fees: undefined,
  formatters: undefined,
  id: base.id,
  name: base.name,
  nativeCurrency: base.nativeCurrency,
  rpcUrls: base.rpcUrls,
  serializers: undefined,
}

export enum ChainId {
  BASE = base.id,
}

export const CHAIN_QUERY_NAME: Record<ChainId, string> = {
  [ChainId.BASE]: 'base',
}

const CHAIN_QUERY_NAME_TO_ID = Object.entries(CHAIN_QUERY_NAME).reduce((acc, [chainId, chainName]) => {
  return {
    [chainName.toLowerCase()]: chainId as unknown as ChainId,
    ...acc,
  }
}, {} as Record<string, ChainId>)

export const CHAINS: [Chain, ...Chain[]] = [
  base
]

export const PUBLIC_NODES: Record<ChainId, string[] | readonly string[]> = {
  [ChainId.BASE]: [...base.rpcUrls.default.http],
}

export const getChainId = memoize((chainName: string) => {
  if (!chainName) return undefined
  return CHAIN_QUERY_NAME_TO_ID[chainName.toLowerCase()] ? +CHAIN_QUERY_NAME_TO_ID[chainName.toLowerCase()] : undefined
})